from service import login_service

if __name__ == '__main__':
    login_service.check_user()
